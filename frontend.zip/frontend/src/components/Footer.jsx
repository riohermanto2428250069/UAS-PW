import React from "react";

export default function Footer() {
    return (
<footer className="main-footer text-center border-top py-3">
    <div className="text-muted">
        © 2025 <strong>SOMESTOCK</strong>
    </div>
</footer>

    );
}
