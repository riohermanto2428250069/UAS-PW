"use strict";

$(".pwstrength").pwstrength();
